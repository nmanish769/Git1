@echo off
cd /d "%~dp0"
echo ===================================================
echo Pushing OpenLearn AI to GitHub (https://github.com/nmanish769/Git1.git)
echo ===================================================
git push -u origin main
echo.
pause
